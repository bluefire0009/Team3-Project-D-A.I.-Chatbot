from openai import AzureOpenAI
import requests
import os
from promptflow import tool

# Set these via environment variables or directly here

@tool
def Lookup(input1: str) -> str:
    openai_client = AzureOpenAI(
    api_key= "CgKQ2EJeCgKn0sZK0kOAbxtrTjAFUZhVJOlT9EXELTvWjIkQuMXCJQQJ99BDAC5RqLJXJ3w3AAAAACOGQcR4",
    api_version="2025-01-01-preview",
    azure_endpoint= "https://ai-socialekaartbotaifoundry951475773397.services.ai.azure.com/"
    )

    # Step 1: Create embedding from question
    text = input1.replace("\n", " ").strip()

    # Embedding call with deployment_id
    resp = openai_client.embeddings.create(
        input=text,                                  
        model="text-embedding-ada-002")
    vec = resp.data[0].embedding


    # Step 2: Query Azure Cognitive Search
    search_url = "https://ai-search-sociale-kaart-bot.search.windows.net/indexes/bubbly-longan-cyc5cv665m/docs/search?api-version=2025-01-01-preview"
    headers = {
        "Content-Type": "application/json",
        "api-key": "CgKQ2EJeCgKn0sZK0kOAbxtrTjAFUZhVJOlT9EXELTvWjIkQuMXCJQQJ99BDAC5RqLJXJ3w3AAAAACOGQcR4"
    }
    body = {
        "search": input1,
        "top": 5,
        "queryType": "simple",
        "searchFields": "title,content",
        "select": "id,title,content,url"
    }

    response = requests.post(search_url, headers=headers, json=body)
    response.raise_for_status()
    results = response.json().get("value", [])

    # 4 Return the snippets
    return "\n\n".join(doc.get("content", "") for doc in results) or "No relevant data found."